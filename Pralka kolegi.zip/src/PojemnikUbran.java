public class PojemnikUbran extends Komponent {
    public PojemnikUbran(int pojemnosc, boolean isWorking) {
        super(pojemnosc, isWorking);
    }
}
