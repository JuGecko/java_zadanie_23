public class PompaWody extends Komponent {
    PompaWody(int pojemnosc, boolean isWorking){
        super(pojemnosc, isWorking);
    }
}
