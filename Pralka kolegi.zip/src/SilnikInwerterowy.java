public class SilnikInwerterowy extends Komponent {
    SilnikInwerterowy(int pojemnosc, boolean isWorking){
        super(pojemnosc, isWorking);
    }
}
