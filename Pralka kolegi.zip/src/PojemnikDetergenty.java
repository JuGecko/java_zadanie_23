public class PojemnikDetergenty extends Komponent{
    public PojemnikDetergenty(int pojemnosc, boolean isWorking) {
        super(pojemnosc, isWorking);
    }
}
