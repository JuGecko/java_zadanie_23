public class ElektrozaworyWodne extends Komponent{
    ElektrozaworyWodne(int cisnienie, boolean isWorking) {
        super(cisnienie, isWorking);
    };
}
